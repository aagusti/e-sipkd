RekeningData = {
    'options': ['insert if not exists'],
    'csv': 'rekening.csv',
}
