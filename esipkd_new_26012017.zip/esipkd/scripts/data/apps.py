AppsData = [
    """dict(
        id=1,
        kode='admin',
        nama='Administrator',
        tahun=2014,
        ),
    dict(
        id=2,
        kode='gaji',
        nama='Gaji Pegawai dan Potongan',
        tahun=None,
        ),
    dict(
        id=3,
        kode='eis',
        nama='Eksekutif Summary',
        tahun=None,
        ),
    dict(
        id=4,
        kode='skpd',
        nama='Penatausahaan dan Akuntansi SKPD',
        tahun=2015,
        ),
    dict(
        id=5,
        kode='anggaran',
        nama='Anggaran',
        tahun=2015,
        ),
    dict(
        id=6,
        kode='tu-skpd',
        nama='Penatausahaan SKPD',
        tahun=2015,
        ),
    dict(
        id=7,
        kode='tu-ppkd',
        nama='Penatausahaan PPKD',
        tahun=2015,
        ),
    dict(
        id=8,
        kode='ak-ppkd',
        nama='Akuntasi PPKD',
        tahun=2015,
        ),
    dict(
        id=9,
        kode='aset',
        nama='Aset',
        tahun=2015,
        ),
    """
]

