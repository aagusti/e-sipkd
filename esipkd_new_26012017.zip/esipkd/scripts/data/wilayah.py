WilayahData = {
    'options': ['insert if not exists'],
    'csv': 'wilayah.csv',
}
