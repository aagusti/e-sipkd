SektorData = {
    'options': ['insert if not exists'],
    'csv': 'sektor.csv',
}
