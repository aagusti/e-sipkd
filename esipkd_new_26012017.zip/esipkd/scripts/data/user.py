UserData = [
    dict(
        id=1,
        email='admin@local',
        user_name='admin',
        password='admin',
        status=1,
        ),
    dict(
        id=2,
        email='anonymous@local',
        user_name='anonymous',
        status=0,
        ),
    ]
