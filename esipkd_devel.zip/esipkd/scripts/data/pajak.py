PajakData = {
    'options': ['insert if not exists'],
    'csv': 'pajak.csv',
}
