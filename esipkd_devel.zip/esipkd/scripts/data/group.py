GroupData = {
    'options': ['insert if not exists'],
    'csv': 'group.csv',
}
