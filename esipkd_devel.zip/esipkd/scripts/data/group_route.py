GroupRouteData = {
    'options': ['insert if not exists'],
    'csv': 'group_route.csv',
}
