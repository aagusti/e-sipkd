JnsPajakData = {
    'options': ['insert if not exists'],
    'csv': 'jns_pajak.csv',
}
